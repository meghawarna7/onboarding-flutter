import 'package:flutter/material.dart';
import 'package:onboarding/onboarding_page.dart'; // Assuming OnboardingPageModel is defined here

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Onboarding',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: OnboardingPage(
        // Use home instead of routes when there's no need for named routes
        pages: [
          OnboardingPageModel(
            title: 'පැන්සල',
            description:
                '"අධ්‍යාපනය යනු ජීවිතයට සූදානම් වීමක් මිස අධ්‍යාපනය යනු ජීවිතයම නොවේ.',
            image: 'assets/image0.png',
            bgColor: Color(0xff020202),
          ),
          OnboardingPageModel(
            title: 'එකතුවෙලා ඉගෙන ගමු.',
            description:
                'සෑම ශ්‍රේණියකම සෑම වාරයකටම අදාළ paper කිරීමට ඔබට හැකියාව ඇත ',
            image: 'assets/image1.png',
            bgColor: const Color(0xff1c1d1d),
          ),
          OnboardingPageModel(
            title: 'පේපර් ඉවර කර ප්‍රතිපල බලා ගත හැක ',
            description: ' පිළිතුරු සම්බන්ධව ගැටලුවක් ඇත්නම් විමසිය හැක.',
            image: 'assets/image2.png',
            bgColor: const Color(0xff393a3a),
          ),
          OnboardingPageModel(
            title: 'ලකුණු අනුව Ranking කර ඇත ',
            description: ' පේපර්වල ඇති ප්‍රශ්න නිරතුරුව update  කරනු ලැබේ.',
            image: 'assets/image3.png',
            bgColor: Color(0xff7a7c7c),
          ),
        ],
      ),
    );
  }
}
