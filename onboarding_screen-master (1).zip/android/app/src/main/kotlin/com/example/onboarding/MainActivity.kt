package com.example.onboarding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
